﻿Public Class APTScene
    Public avg As Long
    Public firstFrameIMG As Bitmap
    Public lastFrameIMG As Bitmap
    Public firstFrame As Long
    Public lastFrame As Long
    Public motionAvg As Long
    Public falsePositive As Boolean

End Class
