﻿Public Class TimeLine

    Private Sub TimeLine_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub TimeLine_Resize(sender As Object, e As EventArgs) Handles Me.Resize

    End Sub
End Class
